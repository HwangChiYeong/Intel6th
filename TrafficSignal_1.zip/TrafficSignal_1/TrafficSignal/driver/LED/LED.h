﻿
#ifndef LED_H_
#define LED_H_

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

#define		LED_DDR			DDRF
#define		trafficLedPORT	PORTF



void Led_init();
void Led_writeData(uint8_t data);
void LED_allOff();
void LED_allOn();

#endif