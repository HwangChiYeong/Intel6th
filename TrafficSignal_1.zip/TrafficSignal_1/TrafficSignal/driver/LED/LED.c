﻿#include "LED.h"

void Led_init()
{
	LED_DDR = 0xff;
}

void Led_writeData(uint8_t data)
{
	trafficLedPORT = data;
}

void TrafficSignal_RedGreen()
{
	trafficLedPORT = ((1<<0) | (1<<5));
}

void TrafficSignal_RedYellow()
{
	trafficLedPORT = ((1<<0) | (1<<4));
}

void TrafficSignal_GreenRed()
{
	trafficLedPORT = ((1<<2) | (1<<3));
}

void TrafficSignal_YellowRed()
{
	trafficLedPORT = ((1<<1) | (1<<3));
}
