﻿#include "TrafficSignal.h"

button_t btnAuto, btnManual, btnSwitching ;
uint8_t trafficState;
uint32_t timeTick =0;
uint8_t ledModeState;

void TrafficSignal_init()
{
	Led_init();
	Button_init(&btnAuto, &DDRA, &PINA, 0);
	Button_init(&btnManual, &DDRA, &PINA, 1);
	Button_init(&btnSwitching, &DDRA, &PINA, 2);
	//uint8_t trafficModeState = AUTO;
	trafficState = RED_GREEN;
}
void TrafficSignal_execute()
{
	if(Button_GetState(&btnAuto) == ACT_RELEASED)
	{
		ledModeState = B_AUTO;
	}
	if(Button_GetState(&btnManual) == ACT_RELEASED)
	{
		ledModeState = B_MANUAL;
	}
	
	switch(ledModeState)
	{
		case B_AUTO :
		TrafficSignal_Auto();
		break;
		case B_MANUAL :
		TrafficSignal_Manual();
		break;
	}
	_delay_ms(1);
	timeTick++;
}
void TrafficSignal_Auto()
{
	static uint32_t prevTime;
	switch(trafficState)
	{
		case RED_GREEN :
		TrafficSignal_RedGreen();
		if((timeTick - prevTime) >= 3000)
		{
			trafficState = RED_YELLOW;
			prevTime = timeTick;
		}
		break;
		case RED_YELLOW :
		TrafficSignal_RedYellow();
		if((timeTick - prevTime) >= 1000)
		{
			trafficState = GREEN_RED;
			prevTime = timeTick;
		}
		break;
		case GREEN_RED :
		TrafficSignal_GreenRed();
		if((timeTick - prevTime) >= 3000)
		{
			trafficState = YELLOW_RED;
			prevTime = timeTick;
		}
		break;
		case YELLOW_RED:
		TrafficSignal_YellowRed();
		if((timeTick - prevTime) >= 3000)
		{
			trafficState = RED_GREEN;
			prevTime = timeTick;
		}
		break;
	}
}

void TrafficSignal_Manual()
{
	switch(trafficState)
	{
		case RED_GREEN :
		TrafficSignal_RedGreen();
		if(Button_GetState(&btnSwitching) == ACT_RELEASED )
		{
			trafficState = RED_YELLOW;
		}
		break;
		case RED_YELLOW :
		TrafficSignal_RedYellow();
		if(Button_GetState(&btnSwitching) == ACT_RELEASED )
		{
			trafficState = GREEN_RED;
		}
		break;
		case GREEN_RED :
		TrafficSignal_GreenRed();
		if(Button_GetState(&btnSwitching) == ACT_RELEASED )
		{
			trafficState = YELLOW_RED;
		}
		break;
		case YELLOW_RED :
		TrafficSignal_YellowRed();
		if(Button_GetState(&btnSwitching) == ACT_RELEASED )
		{
			trafficState = RED_GREEN;
		}
		break;
	}
}