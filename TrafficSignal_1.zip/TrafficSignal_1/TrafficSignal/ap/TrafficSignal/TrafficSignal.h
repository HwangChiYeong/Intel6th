﻿
#ifndef TRAFFICSIGNAL_H_
#define TRAFFICSIGNAL_H_

#include  "../../driver/Button/button1.h"
#include  "../../driver/LED/LED.h"
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

#define		B_AUTO					0
#define		B_MANUAL				1
#define		B_SWITCHING				2
enum {AUTO, MANUAL};
enum{RED_GREEN, RED_YELLOW, GREEN_RED, YELLOW_RED};
void TrafficSignal_execute();
void TrafficSignal_Auto();
void TrafficSignal_Manual();
#endif /* TRAFFICSIGNAL_H_ */