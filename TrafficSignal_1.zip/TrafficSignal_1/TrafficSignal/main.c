#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/io.h>
#include "ap/TrafficSignal/TrafficSignal.h"
//#define		trafficButtonDDR		DDRA
//#define		trafficButtonPIN		PINA
//#define		trafficLedPORT			PORTF
//#define		trafficLedDDR			DDRF



//uint8_t trafficState;
//uint32_t timeTick =0;
//int main(void)
//{
	//trafficButtonDDR &= ~((1<< B_AUTO) | (1<<B_MANUAL) | (1<<B_SWITCHING));
	//trafficLedDDR |= ((1<<0) | (1<<1) | (1<<3) | (1<<4) | (1<<5));
	//
	//uint8_t trafficModeState = AUTO;
	//trafficState = RED_GREEN;
	//while (1)
	//{
		////mode event check
		//if((trafficButtonPIN & (1<<B_AUTO)) == 0)
		//{
			//trafficModeState = AUTO;
		//}
		//else if((trafficButtonPIN & (1<<B_MANUAL)) == 0)
		//{
			//trafficModeState = MANUAL;
		//}
		////mode running
		//switch(trafficModeState)
		//{
			//case AUTO :
			//TrafficSignal_Auto();
			//break;
			//case MANUAL :
			//TrafficSignal_Manual();
			//break;
		//}
		//_delay_ms(1);
		//timeTick++;
	//}
//}
//
//void TrafficSignal_Auto()
//{
	//static uint32_t prevTime =0;
	//
	//switch(trafficState)
	//{
		//case RED_GREEN :
		//TrafficSignal_RedGreen();
		////_delay_ms(3000);
		//if(timeTick - prevTime >= 3000)
		//{
			//prevTime = timeTick;
			//trafficState = RED_YELLOW;
		//}
		//break;
		//case RED_YELLOW :
		//TrafficSignal_RedYellow();
		////_delay_ms(1000);
		//if(timeTick - prevTime >= 1000)
		//{
			//prevTime = timeTick;
			//trafficState = GREEN_RED;
		//}
		//
		//break;
		//case GREEN_RED :
		//TrafficSignal_GreenRed();
		////_delay_ms(3000);
		//if(timeTick - prevTime >= 3000)
		//{
			//prevTime = timeTick;
			//trafficState =  YELLOW_RED;
		//}
		//break;
		//case YELLOW_RED :
		//TrafficSignal_YellowRed();
		////_delay_ms(1000);
		//if(timeTick - prevTime >= 1000)
		//{
			//prevTime = timeTick;
			//trafficState =RED_GREEN;
		//}
		//
		//break;
	//}
//}
//void TrafficSignal_Manual()
//{
	//switch(trafficState)
	//{
		//case RED_GREEN :
		//TrafficSignal_RedGreen();
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
			//trafficState = RED_YELLOW;
		//}
		//break;
		//case RED_YELLOW :
		//TrafficSignal_RedYellow();
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
			//trafficState = GREEN_RED;
		//}
		//break;
		//case GREEN_RED :
		//TrafficSignal_GreenRed();
		//if((trafficButtonPIN & (1<<B_SWITCHING))==0)
		//{
			//trafficState = YELLOW_RED;
		//}
		//break;
		//case YELLOW_RED :
		//TrafficSignal_YellowRed();
		//if((trafficButtonPIN & (1<<B_SWITCHING)) ==0)
		//{
			//trafficState = RED_GREEN;
		//}
		//break;
	//}
//}
//
//void TrafficSignal_RedGreen()
//{
	//trafficLedPORT = ((1<<0) | (1<<5));
//}
//void TrafficSignal_RedYellow()
//{
	//trafficLedPORT = ((1<<0) | (1<<4));
//}
//void TrafficSignal_GreenRed()
//{
	//trafficLedPORT = ((1<<2) | (1<<3));
//}
//void TrafficSignal_YellowRed()
//{
	//trafficLedPORT = ((1<<1) | (1<<3));
//}

int main(void)
{
	
	TrafficSignal_init();
	
	while(1)
	{
		TrafficSignal_execute();
		
	}
}